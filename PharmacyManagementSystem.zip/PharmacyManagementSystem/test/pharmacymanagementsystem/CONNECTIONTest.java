/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package pharmacymanagementsystem;

import pharmacymanagementsystem.CONNECTION;
import java.sql.Connection;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author MAC
 */
public class CONNECTIONTest {
    
    public CONNECTIONTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of GETCONNECTION method, of class CONNECTION.
     */
    @Test
    public void testGETCONNECTION() {
        System.out.println("GETCONNECTION");
        Connection expResult = null;
        Connection result = CONNECTION.GETCONNECTION();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of authenticateUser method, of class CONNECTION.
     */
    @Test
    public void testAuthenticateUser() {
        System.out.println("authenticateUser");
        String enteredUsername = "";
        String enteredPassword = "";
        boolean expResult = false;
        boolean resulta = CONNECTION.authenticateUserA(enteredUsername, enteredPassword);
         boolean resultp = CONNECTION.authenticateUserP(enteredUsername, enteredPassword);
        assertEquals(expResult, resulta);
        assertEquals(expResult, resultp);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of main method, of class CONNECTION.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        CONNECTION.main(args);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}