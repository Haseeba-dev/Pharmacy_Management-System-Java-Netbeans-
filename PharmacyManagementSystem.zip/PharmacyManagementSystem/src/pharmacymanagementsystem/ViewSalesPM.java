/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package pharmacymanagementsystem;

import java.awt.BorderLayout;
import java.awt.Color;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PiePlot;
import org.jfree.data.general.DefaultPieDataset;

/**
 *
 * @author MAC
 */
public class ViewSalesPM extends javax.swing.JFrame {

    /**
     * Creates new form viewsales
     */
    public ViewSalesPM() {
        initComponents();
    }
    
    
     
     
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        Sales = new javax.swing.JPanel();
        jLabel21 = new javax.swing.JLabel();
        Dashboard = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        Customer = new javax.swing.JPanel();
        jLabel19 = new javax.swing.JLabel();
        Inventory = new javax.swing.JPanel();
        jLabel18 = new javax.swing.JLabel();
        Supplier = new javax.swing.JPanel();
        jLabel22 = new javax.swing.JLabel();
        Staff = new javax.swing.JPanel();
        jLabel23 = new javax.swing.JLabel();
        Manufacturer = new javax.swing.JPanel();
        jLabel24 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        View_Daily = new rojerusan.RSMaterialButtonRectangle();
        ViewMonthlySales = new rojerusan.RSMaterialButtonRectangle();
        ViewYearlySales = new rojerusan.RSMaterialButtonRectangle();
        jLabel13 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(38, 143, 249));

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pharmacymanagementsystem/myicons/search_26px.png"))); // NOI18N

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 45)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(51, 51, 51));
        jLabel5.setText("|");

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pharmacymanagementsystem/myicons/bell_26px.png"))); // NOI18N

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pharmacymanagementsystem/myicons/group_message_26px.png"))); // NOI18N

        jLabel8.setFont(new java.awt.Font("Tahoma", 0, 45)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(51, 51, 51));
        jLabel8.setText("|");

        jLabel9.setFont(new java.awt.Font("Yu Gothic UI", 0, 25)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pharmacymanagementsystem/myicons/male_user_50px.png"))); // NOI18N
        jLabel9.setText(" HELLO ADMIN");

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 60)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(51, 51, 51));
        jLabel2.setText("|");

        jLabel11.setFont(new java.awt.Font("Yu Gothic UI", 1, 36)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("DASHBOARD");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 233, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 831, Short.MAX_VALUE)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel8)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel6)
                .addGap(34, 34, 34)
                .addComponent(jLabel9)
                .addGap(141, 141, 141))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel8, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(49, 49, 49))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel6)
                            .addComponent(jLabel7)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(jLabel4)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 0, -1, 80));

        jPanel2.setBackground(new java.awt.Color(38, 143, 249));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Sales.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Sales.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                SalesMouseClicked(evt);
            }
        });

        jLabel21.setBackground(new java.awt.Color(0, 0, 0));
        jLabel21.setFont(new java.awt.Font("Yu Gothic UI", 0, 18)); // NOI18N
        jLabel21.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pharmacymanagementsystem/myicons/7705396_pie_chart_piece_sales_icon.png"))); // NOI18N
        jLabel21.setText("VIEW SALES");
        jLabel21.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel21MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout SalesLayout = new javax.swing.GroupLayout(Sales);
        Sales.setLayout(SalesLayout);
        SalesLayout.setHorizontalGroup(
            SalesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SalesLayout.createSequentialGroup()
                .addGap(77, 77, 77)
                .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(77, Short.MAX_VALUE))
        );
        SalesLayout.setVerticalGroup(
            SalesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SalesLayout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(26, Short.MAX_VALUE))
        );

        jPanel2.add(Sales, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 300, -1, 80));

        Dashboard.setBackground(new java.awt.Color(38, 143, 249));
        Dashboard.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Dashboard.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                DashboardMouseClicked(evt);
            }
        });

        jLabel10.setFont(new java.awt.Font("Yu Gothic UI", 0, 18)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pharmacymanagementsystem/myicons/4737437_manage_dashboard_analytic_icon.png"))); // NOI18N
        jLabel10.setText("DASHBOARD");
        jLabel10.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel10MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout DashboardLayout = new javax.swing.GroupLayout(Dashboard);
        Dashboard.setLayout(DashboardLayout);
        DashboardLayout.setHorizontalGroup(
            DashboardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(DashboardLayout.createSequentialGroup()
                .addGap(74, 74, 74)
                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(80, Short.MAX_VALUE))
        );
        DashboardLayout.setVerticalGroup(
            DashboardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, DashboardLayout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30))
        );

        jPanel2.add(Dashboard, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 190, 300, 90));

        jLabel3.setFont(new java.awt.Font("Yu Gothic UI", 1, 27)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(242, 242, 242));
        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pharmacymanagementsystem/myicons/logo pharmacy2.png"))); // NOI18N
        jLabel3.setText("EMERALD care");
        jPanel2.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, 240, 78));

        jLabel1.setBackground(new java.awt.Color(0, 0, 0));
        jLabel1.setFont(new java.awt.Font("Yu Gothic UI", 0, 14)); // NOI18N
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pharmacymanagementsystem/myicons/icons8_menu_48px_1.png"))); // NOI18N
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 30, -1, 30));

        Customer.setBackground(new java.awt.Color(38, 143, 249));
        Customer.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Customer.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                CustomerMouseClicked(evt);
            }
        });

        jLabel19.setBackground(new java.awt.Color(240, 240, 240));
        jLabel19.setFont(new java.awt.Font("Yu Gothic UI", 0, 18)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(255, 255, 255));
        jLabel19.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pharmacymanagementsystem/myicons/6843096_customer_loyalty_loyalty customer_relationship_reliability_icon.png"))); // NOI18N
        jLabel19.setText("CUSTOMERS");

        javax.swing.GroupLayout CustomerLayout = new javax.swing.GroupLayout(Customer);
        Customer.setLayout(CustomerLayout);
        CustomerLayout.setHorizontalGroup(
            CustomerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(CustomerLayout.createSequentialGroup()
                .addGap(76, 76, 76)
                .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(78, Short.MAX_VALUE))
        );
        CustomerLayout.setVerticalGroup(
            CustomerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(CustomerLayout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(29, Short.MAX_VALUE))
        );

        jPanel2.add(Customer, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 400, 300, 90));

        Inventory.setBackground(new java.awt.Color(38, 143, 249));
        Inventory.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Inventory.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                InventoryMouseClicked(evt);
            }
        });

        jLabel18.setBackground(new java.awt.Color(240, 240, 240));
        jLabel18.setFont(new java.awt.Font("Yu Gothic UI", 0, 18)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(255, 255, 255));
        jLabel18.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pharmacymanagementsystem/myicons/9025885_shopping_cart_icon.png"))); // NOI18N
        jLabel18.setText("VIEW INVENTORY");

        javax.swing.GroupLayout InventoryLayout = new javax.swing.GroupLayout(Inventory);
        Inventory.setLayout(InventoryLayout);
        InventoryLayout.setHorizontalGroup(
            InventoryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, InventoryLayout.createSequentialGroup()
                .addContainerGap(61, Short.MAX_VALUE)
                .addComponent(jLabel18)
                .addGap(67, 67, 67))
        );
        InventoryLayout.setVerticalGroup(
            InventoryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, InventoryLayout.createSequentialGroup()
                .addContainerGap(16, Short.MAX_VALUE)
                .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(31, 31, 31))
        );

        jPanel2.add(Inventory, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 500, 300, 90));

        Supplier.setBackground(new java.awt.Color(38, 143, 249));
        Supplier.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Supplier.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                SupplierMouseClicked(evt);
            }
        });

        jLabel22.setBackground(new java.awt.Color(240, 240, 240));
        jLabel22.setFont(new java.awt.Font("Yu Gothic UI", 0, 18)); // NOI18N
        jLabel22.setForeground(new java.awt.Color(255, 255, 255));
        jLabel22.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pharmacymanagementsystem/myicons/9989414_rating_evaluation_grade_ranking_rate_icon.png"))); // NOI18N
        jLabel22.setText("SUPPLIERS");

        javax.swing.GroupLayout SupplierLayout = new javax.swing.GroupLayout(Supplier);
        Supplier.setLayout(SupplierLayout);
        SupplierLayout.setHorizontalGroup(
            SupplierLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SupplierLayout.createSequentialGroup()
                .addGap(75, 75, 75)
                .addComponent(jLabel22, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(79, Short.MAX_VALUE))
        );
        SupplierLayout.setVerticalGroup(
            SupplierLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SupplierLayout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addComponent(jLabel22, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(35, Short.MAX_VALUE))
        );

        jPanel2.add(Supplier, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 590, -1, -1));

        Staff.setBackground(new java.awt.Color(38, 143, 249));
        Staff.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Staff.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                StaffMouseClicked(evt);
            }
        });

        jLabel23.setBackground(new java.awt.Color(38, 143, 249));
        jLabel23.setFont(new java.awt.Font("Yu Gothic UI", 0, 18)); // NOI18N
        jLabel23.setForeground(new java.awt.Color(255, 255, 255));
        jLabel23.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pharmacymanagementsystem/myicons/9070684_file_staff_one_icon.png"))); // NOI18N
        jLabel23.setText("MANAGE STAFF");

        javax.swing.GroupLayout StaffLayout = new javax.swing.GroupLayout(Staff);
        Staff.setLayout(StaffLayout);
        StaffLayout.setHorizontalGroup(
            StaffLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(StaffLayout.createSequentialGroup()
                .addGap(62, 62, 62)
                .addComponent(jLabel23, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(68, Short.MAX_VALUE))
        );
        StaffLayout.setVerticalGroup(
            StaffLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, StaffLayout.createSequentialGroup()
                .addContainerGap(30, Short.MAX_VALUE)
                .addComponent(jLabel23, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(31, 31, 31))
        );

        jPanel2.add(Staff, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 690, -1, -1));

        Manufacturer.setBackground(new java.awt.Color(38, 143, 249));
        Manufacturer.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Manufacturer.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ManufacturerMouseClicked(evt);
            }
        });

        jLabel24.setBackground(new java.awt.Color(38, 143, 249));
        jLabel24.setFont(new java.awt.Font("Yu Gothic UI", 0, 18)); // NOI18N
        jLabel24.setForeground(new java.awt.Color(255, 255, 255));
        jLabel24.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pharmacymanagementsystem/myicons/icons8-manufacture-30.png"))); // NOI18N
        jLabel24.setText("MANUFACTURER");

        javax.swing.GroupLayout ManufacturerLayout = new javax.swing.GroupLayout(Manufacturer);
        Manufacturer.setLayout(ManufacturerLayout);
        ManufacturerLayout.setHorizontalGroup(
            ManufacturerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ManufacturerLayout.createSequentialGroup()
                .addGap(56, 56, 56)
                .addComponent(jLabel24)
                .addContainerGap(73, Short.MAX_VALUE))
        );
        ManufacturerLayout.setVerticalGroup(
            ManufacturerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ManufacturerLayout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(jLabel24, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(31, Short.MAX_VALUE))
        );

        jPanel2.add(Manufacturer, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 790, 300, -1));

        jLabel26.setBackground(new java.awt.Color(38, 143, 249));
        jLabel26.setFont(new java.awt.Font("Yu Gothic UI", 0, 18)); // NOI18N
        jLabel26.setForeground(new java.awt.Color(255, 255, 255));
        jLabel26.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pharmacymanagementsystem/myicons/icons8-manufacture-30.png"))); // NOI18N
        jLabel26.setText("LOGOUT");
        jLabel26.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel26.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel26MouseClicked(evt);
            }
        });
        jPanel2.add(jLabel26, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 940, -1, 33));

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 1020));

        View_Daily.setBackground(new java.awt.Color(38, 143, 249));
        View_Daily.setBorder(null);
        View_Daily.setText("VIEW DAILY SALES");
        View_Daily.setFont(new java.awt.Font("Yu Gothic UI", 1, 18)); // NOI18N
        View_Daily.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                View_DailyActionPerformed(evt);
            }
        });
        getContentPane().add(View_Daily, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 200, -1, 100));

        ViewMonthlySales.setBackground(new java.awt.Color(38, 143, 249));
        ViewMonthlySales.setText("VIEW MONTHLY SALES");
        ViewMonthlySales.setFont(new java.awt.Font("Yu Gothic UI", 1, 18)); // NOI18N
        ViewMonthlySales.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ViewMonthlySalesActionPerformed(evt);
            }
        });
        getContentPane().add(ViewMonthlySales, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 400, -1, 100));

        ViewYearlySales.setBackground(new java.awt.Color(38, 143, 249));
        ViewYearlySales.setText("VIEW YEARLY SALES");
        ViewYearlySales.setFont(new java.awt.Font("Yu Gothic UI", 1, 18)); // NOI18N
        ViewYearlySales.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ViewYearlySalesActionPerformed(evt);
            }
        });
        getContentPane().add(ViewYearlySales, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 600, -1, 100));

        jLabel13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pharmacymanagementsystem/myicons/2457279.jpg"))); // NOI18N
        jLabel13.setText("jLabel13");
        getContentPane().add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 80, 1630, 950));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jLabel21MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel21MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel21MouseClicked

    private void jLabel10MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel10MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel10MouseClicked

    private void ViewYearlySalesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ViewYearlySalesActionPerformed
       ViewYearlySalesPM ViewYearlySalesPM = new ViewYearlySalesPM();
       this.setVisible(false);
        ViewYearlySalesPM.setVisible(true);
    }//GEN-LAST:event_ViewYearlySalesActionPerformed

    private void View_DailyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_View_DailyActionPerformed
         ViewDailySalesPM  ViewDailySalesPM = new ViewDailySalesPM();
         this.setVisible(false);
        ViewDailySalesPM.setVisible(true);
    }//GEN-LAST:event_View_DailyActionPerformed

    private void ViewMonthlySalesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ViewMonthlySalesActionPerformed
      ViewMonthlySalesPM  ViewMonthlySalesPM = new ViewMonthlySalesPM();
      this.setVisible(false);
        ViewMonthlySalesPM.setVisible(true);
    }//GEN-LAST:event_ViewMonthlySalesActionPerformed

    private void DashboardMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_DashboardMouseClicked
        Dashboard_AdminPM Dashboard = new Dashboard_AdminPM();
        this.setVisible(false);
        Dashboard.setVisible(true);

    }//GEN-LAST:event_DashboardMouseClicked

    private void SalesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SalesMouseClicked

	ViewSalesPM Sales=new ViewSalesPM();
        this.setVisible(false);
        Sales.setVisible(true);
    }//GEN-LAST:event_SalesMouseClicked

    private void CustomerMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_CustomerMouseClicked

	ViewCustomerPM Customer = new ViewCustomerPM();
        this.setVisible(false);
        Customer.setVisible(true);

    }//GEN-LAST:event_CustomerMouseClicked

    private void InventoryMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_InventoryMouseClicked

	ViewInventoryPM Inventory = new ViewInventoryPM();
        this.setVisible(false);
        Inventory.setVisible(true);

    }//GEN-LAST:event_InventoryMouseClicked

    private void SupplierMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SupplierMouseClicked

	ViewSupplierPM Supplier = new ViewSupplierPM();
        this.setVisible(false);
        Supplier.setVisible(true);

    }//GEN-LAST:event_SupplierMouseClicked

    private void StaffMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_StaffMouseClicked
  
	ViewManageStaffPM Staff = new ViewManageStaffPM();
        this.setVisible(false);
        Staff.setVisible(true);
    }//GEN-LAST:event_StaffMouseClicked

    private void ManufacturerMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ManufacturerMouseClicked
        ViewManufacturer Manufacturer = new ViewManufacturer();
        this.setVisible(false);
        Manufacturer.setVisible(true);
    }//GEN-LAST:event_ManufacturerMouseClicked

    private void jLabel26MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel26MouseClicked
        HomePagePM hpg=new HomePagePM();
        this.setVisible(false);
        hpg.setVisible(true);

        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel26MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ViewSalesPM.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ViewSalesPM.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ViewSalesPM.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ViewSalesPM.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ViewSalesPM().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel Customer;
    private javax.swing.JPanel Dashboard;
    private javax.swing.JPanel Inventory;
    private javax.swing.JPanel Manufacturer;
    private javax.swing.JPanel Sales;
    private javax.swing.JPanel Staff;
    private javax.swing.JPanel Supplier;
    private rojerusan.RSMaterialButtonRectangle ViewMonthlySales;
    private rojerusan.RSMaterialButtonRectangle ViewYearlySales;
    private rojerusan.RSMaterialButtonRectangle View_Daily;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    // End of variables declaration//GEN-END:variables
}
