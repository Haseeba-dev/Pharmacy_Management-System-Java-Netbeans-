/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package pharmacymanagementsystem;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.MouseEvent;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import static pharmacymanagementsystem.CONNECTION.GETCONNECTION;

public class Pharmacist_OrderPMS extends javax.swing.JFrame {

    private final DefaultTableModel model;
    private final DefaultTableModel cartModel;

    public Pharmacist_OrderPMS() {
        initComponents();
        model = new DefaultTableModel();
        viewinventorytable.setModel(model); // Assuming viewinventorytable is your table component
        model.addColumn("Inventory ID");
        model.addColumn("Item Name");
        model.addColumn("Category");
        model.addColumn("Unit Price");
        model.addColumn("Stock");

        // Initialize CartTable
        cartModel = new DefaultTableModel();
        CartTable.setModel(cartModel);
        cartModel.addColumn("Product ID");
        cartModel.addColumn("Item Name");
        cartModel.addColumn("Category");
        cartModel.addColumn("Unit Price");
        cartModel.addColumn("Quantity");

        // Load data from itemsview into the table
        populateInventoryView();
    }

    private void theder() {
        JTableHeader thead = viewinventorytable.getTableHeader();
        thead.setBackground(Color.LIGHT_GRAY);
        thead.setForeground(Color.BLUE);
        thead.setFont(new Font("Yu Gothic UI", Font.BOLD, 18));
    }

    private void populateInventoryView() {
        try (Connection connection = GETCONNECTION()) {
            if (connection != null) {
                String query = "SELECT InventoryItemID, Itemname, category, unitprice, stock FROM InventoryItems";

                try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                    ResultSet resultSet = preparedStatement.executeQuery();

                    model.setRowCount(0); // Clear existing data in the table

                    while (resultSet.next()) {
                        String inventoryItemID = resultSet.getString("InventoryItemID");
                        String itemName = resultSet.getString("Itemname");
                        String category = resultSet.getString("category");
                        double unitPrice = resultSet.getDouble("unitprice");
                        int stock = resultSet.getInt("stock");

                        model.addRow(new Object[]{inventoryItemID, itemName, category, unitPrice, stock});
                    }

                    // Revalidate and repaint to ensure the table updates
                    viewinventorytable.revalidate();
                    viewinventorytable.repaint();
                }
            } else {
                System.out.println("Failed to connect to the database.");
            }
            theder();
        } catch (SQLException e) {
            System.out.println("SQL Exception: " + e.getMessage());
        }
    }

    private void addToCart() {
        try {
            String productID = txtQ3.getText().trim();
            int quantity = Integer.parseInt(txtQ2.getText().trim());

            boolean productExists = false;
            for (int i = 0; i < cartModel.getRowCount(); i++) {
                String existingProductID = cartModel.getValueAt(i, 0).toString();
                if (existingProductID.equals(productID)) {
                    int existingQuantity = Integer.parseInt(cartModel.getValueAt(i, 4).toString());
                    cartModel.setValueAt(existingQuantity + quantity, i, 4);
                    productExists = true;
                    break;
                }
            }

            if (!productExists) {
                for (int i = 0; i < viewinventorytable.getRowCount(); i++) {
                    String inventoryItemID = viewinventorytable.getValueAt(i, 0).toString();
                    if (inventoryItemID.equals(productID)) {
                        String itemName = viewinventorytable.getValueAt(i, 1).toString();
                        String category = viewinventorytable.getValueAt(i, 2).toString();
                        double unitPrice = Double.parseDouble(viewinventorytable.getValueAt(i, 3).toString());

                        cartModel.addRow(new Object[]{productID, itemName, category, unitPrice, quantity});
                        break;
                    }
                }
            }

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Please enter a valid Product ID and Quantity.");
        }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel6 = new javax.swing.JPanel();
        txtQ2 = new javax.swing.JTextField();
        jLabel83 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel84 = new javax.swing.JLabel();
        txtQ3 = new javax.swing.JTextField();
        jLabel90 = new javax.swing.JLabel();
        patientid = new javax.swing.JTextField();
        jLabel92 = new javax.swing.JLabel();
        contact = new javax.swing.JTextField();
        jLabel91 = new javax.swing.JLabel();
        customername = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        Invoicebtn = new javax.swing.JButton();
        email = new javax.swing.JTextField();
        jLabel93 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        CartTable = new javax.swing.JTable();
        jScrollPane2 = new javax.swing.JScrollPane();
        viewinventorytable = new javax.swing.JTable();
        jPanel2 = new javax.swing.JPanel();
        Pharma_Inventory = new javax.swing.JPanel();
        jLabel21 = new javax.swing.JLabel();
        Pharma_Dashboard = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        Pharma_customer = new javax.swing.JPanel();
        jLabel22 = new javax.swing.JLabel();
        Pharma_PlaceOrder = new javax.swing.JPanel();
        jLabel20 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtQ2.setFont(new java.awt.Font("Century Gothic", 0, 14)); // NOI18N
        txtQ2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtQ2ActionPerformed(evt);
            }
        });

        jLabel83.setFont(new java.awt.Font("Yu Gothic UI", 0, 18)); // NOI18N
        jLabel83.setForeground(new java.awt.Color(38, 143, 249));
        jLabel83.setText("Quantity");

        jLabel12.setFont(new java.awt.Font("Yu Gothic UI", 1, 36)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(38, 143, 249));
        jLabel12.setText("ORDER");

        jLabel84.setFont(new java.awt.Font("Yu Gothic UI", 0, 18)); // NOI18N
        jLabel84.setForeground(new java.awt.Color(38, 143, 249));
        jLabel84.setText("Item ID");

        txtQ3.setFont(new java.awt.Font("Century Gothic", 0, 14)); // NOI18N
        txtQ3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtQ3ActionPerformed(evt);
            }
        });

        jLabel90.setFont(new java.awt.Font("Yu Gothic UI", 0, 18)); // NOI18N
        jLabel90.setForeground(new java.awt.Color(38, 143, 249));
        jLabel90.setText("Patient ID");

        patientid.setFont(new java.awt.Font("Century Gothic", 0, 14)); // NOI18N
        patientid.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                patientidActionPerformed(evt);
            }
        });

        jLabel92.setFont(new java.awt.Font("Yu Gothic UI", 0, 18)); // NOI18N
        jLabel92.setForeground(new java.awt.Color(38, 143, 249));
        jLabel92.setText("Contact");

        contact.setFont(new java.awt.Font("Century Gothic", 0, 14)); // NOI18N
        contact.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                contactActionPerformed(evt);
            }
        });

        jLabel91.setFont(new java.awt.Font("Yu Gothic UI", 0, 18)); // NOI18N
        jLabel91.setForeground(new java.awt.Color(38, 143, 249));
        jLabel91.setText("Customer Name");

        customername.setFont(new java.awt.Font("Century Gothic", 0, 14)); // NOI18N
        customername.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                customernameActionPerformed(evt);
            }
        });

        jButton1.setFont(new java.awt.Font("Yu Gothic UI", 0, 14)); // NOI18N
        jButton1.setForeground(new java.awt.Color(38, 143, 249));
        jButton1.setText("Add");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        Invoicebtn.setFont(new java.awt.Font("Yu Gothic UI", 0, 14)); // NOI18N
        Invoicebtn.setForeground(new java.awt.Color(38, 143, 249));
        Invoicebtn.setText("Confirm & Generate Invoice");
        Invoicebtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                InvoicebtnActionPerformed(evt);
            }
        });

        email.setFont(new java.awt.Font("Century Gothic", 0, 14)); // NOI18N
        email.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                emailActionPerformed(evt);
            }
        });

        jLabel93.setFont(new java.awt.Font("Yu Gothic UI", 0, 18)); // NOI18N
        jLabel93.setForeground(new java.awt.Color(38, 143, 249));
        jLabel93.setText("Email");

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel12)
                .addGap(239, 239, 239))
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(135, 135, 135)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel6Layout.createSequentialGroup()
                                .addGap(70, 70, 70)
                                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(customername, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel6Layout.createSequentialGroup()
                                        .addGap(15, 15, 15)
                                        .addComponent(jLabel91))
                                    .addGroup(jPanel6Layout.createSequentialGroup()
                                        .addGap(48, 48, 48)
                                        .addComponent(jLabel92))
                                    .addComponent(contact, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(patientid, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(email, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel6Layout.createSequentialGroup()
                                .addGap(100, 100, 100)
                                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel90, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel6Layout.createSequentialGroup()
                                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jLabel84, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(txtQ3, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(148, 148, 148)
                                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtQ2, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel6Layout.createSequentialGroup()
                                        .addGap(8, 8, 8)
                                        .addComponent(jLabel83))))))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(185, 185, 185)
                        .addComponent(Invoicebtn))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(264, 264, 264)
                        .addComponent(jLabel93)))
                .addContainerGap(95, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(jLabel12)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(jLabel84)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtQ3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(jLabel83)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtQ2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 23, Short.MAX_VALUE)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(35, 35, 35)
                .addComponent(jLabel90)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(patientid, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel91)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(customername, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel92)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(contact, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel93)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(email, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(13, 13, 13)
                .addComponent(Invoicebtn, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(37, 37, 37))
        );

        getContentPane().add(jPanel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 110, 550, -1));

        jPanel1.setBackground(new java.awt.Color(38, 143, 249));

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pharmacymanagementsystem/myicons/search_26px.png"))); // NOI18N

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 45)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(51, 51, 51));
        jLabel5.setText("|");

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pharmacymanagementsystem/myicons/bell_26px.png"))); // NOI18N

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pharmacymanagementsystem/myicons/group_message_26px.png"))); // NOI18N

        jLabel8.setFont(new java.awt.Font("Tahoma", 0, 45)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(51, 51, 51));
        jLabel8.setText("|");

        jLabel9.setFont(new java.awt.Font("Yu Gothic UI", 0, 25)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pharmacymanagementsystem/myicons/male_user_50px.png"))); // NOI18N
        jLabel9.setText(" HELLO PHARMACIST");

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 60)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(51, 51, 51));
        jLabel2.setText("|");

        jLabel11.setFont(new java.awt.Font("Yu Gothic UI", 1, 36)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("DASHBOARD");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 233, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 831, Short.MAX_VALUE)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel8)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel6)
                .addGap(34, 34, 34)
                .addComponent(jLabel9)
                .addGap(141, 141, 141))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel8, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(49, 49, 49))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel6)
                            .addComponent(jLabel7)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(jLabel4)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 0, -1, 80));

        CartTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Item ID", " Name", "Quantity", "Price"
            }
        ));
        jScrollPane3.setViewportView(CartTable);

        getContentPane().add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(940, 750, 620, 200));

        viewinventorytable.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        viewinventorytable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Item ID", "Item Name", "Category", "Unit Price", "Stock"
            }
        ));
        jScrollPane2.setViewportView(viewinventorytable);

        getContentPane().add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(950, 110, 950, 520));

        jPanel2.setBackground(new java.awt.Color(38, 143, 249));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Pharma_Inventory.setBackground(new java.awt.Color(38, 143, 249));
        Pharma_Inventory.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Pharma_Inventory.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Pharma_InventoryMouseClicked(evt);
            }
        });

        jLabel21.setBackground(new java.awt.Color(0, 0, 0));
        jLabel21.setFont(new java.awt.Font("Yu Gothic UI", 0, 18)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(255, 255, 255));
        jLabel21.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pharmacymanagementsystem/myicons/9025885_shopping_cart_icon.png"))); // NOI18N
        jLabel21.setText("VIEW INVENTORY");
        jLabel21.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel21MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout Pharma_InventoryLayout = new javax.swing.GroupLayout(Pharma_Inventory);
        Pharma_Inventory.setLayout(Pharma_InventoryLayout);
        Pharma_InventoryLayout.setHorizontalGroup(
            Pharma_InventoryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Pharma_InventoryLayout.createSequentialGroup()
                .addGap(64, 64, 64)
                .addComponent(jLabel21)
                .addContainerGap(64, Short.MAX_VALUE))
        );
        Pharma_InventoryLayout.setVerticalGroup(
            Pharma_InventoryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Pharma_InventoryLayout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(26, Short.MAX_VALUE))
        );

        jPanel2.add(Pharma_Inventory, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 300, -1, 80));

        Pharma_Dashboard.setBackground(new java.awt.Color(38, 143, 249));
        Pharma_Dashboard.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Pharma_Dashboard.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Pharma_DashboardMouseClicked(evt);
            }
        });

        jLabel10.setFont(new java.awt.Font("Yu Gothic UI", 0, 18)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pharmacymanagementsystem/myicons/4737437_manage_dashboard_analytic_icon.png"))); // NOI18N
        jLabel10.setText("DASHBOARD");
        jLabel10.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel10MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout Pharma_DashboardLayout = new javax.swing.GroupLayout(Pharma_Dashboard);
        Pharma_Dashboard.setLayout(Pharma_DashboardLayout);
        Pharma_DashboardLayout.setHorizontalGroup(
            Pharma_DashboardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Pharma_DashboardLayout.createSequentialGroup()
                .addGap(74, 74, 74)
                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(80, Short.MAX_VALUE))
        );
        Pharma_DashboardLayout.setVerticalGroup(
            Pharma_DashboardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Pharma_DashboardLayout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30))
        );

        jPanel2.add(Pharma_Dashboard, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 190, 300, 90));

        jLabel3.setFont(new java.awt.Font("Yu Gothic UI", 1, 27)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(242, 242, 242));
        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pharmacymanagementsystem/myicons/logo pharmacy2.png"))); // NOI18N
        jLabel3.setText("EMERALD care");
        jPanel2.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, 240, 78));

        jLabel1.setBackground(new java.awt.Color(0, 0, 0));
        jLabel1.setFont(new java.awt.Font("Yu Gothic UI", 0, 14)); // NOI18N
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pharmacymanagementsystem/myicons/icons8_menu_48px_1.png"))); // NOI18N
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 30, -1, 30));

        Pharma_customer.setBackground(new java.awt.Color(38, 143, 249));
        Pharma_customer.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Pharma_customer.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Pharma_customerMouseClicked(evt);
            }
        });

        jLabel22.setBackground(new java.awt.Color(0, 0, 0));
        jLabel22.setFont(new java.awt.Font("Yu Gothic UI", 0, 18)); // NOI18N
        jLabel22.setForeground(new java.awt.Color(255, 255, 255));
        jLabel22.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pharmacymanagementsystem/myicons/6843096_customer_loyalty_loyalty customer_relationship_reliability_icon.png"))); // NOI18N
        jLabel22.setText("CUSTOMER");
        jLabel22.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel22MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout Pharma_customerLayout = new javax.swing.GroupLayout(Pharma_customer);
        Pharma_customer.setLayout(Pharma_customerLayout);
        Pharma_customerLayout.setHorizontalGroup(
            Pharma_customerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Pharma_customerLayout.createSequentialGroup()
                .addGap(71, 71, 71)
                .addComponent(jLabel22, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(98, Short.MAX_VALUE))
        );
        Pharma_customerLayout.setVerticalGroup(
            Pharma_customerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Pharma_customerLayout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(jLabel22, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(30, Short.MAX_VALUE))
        );

        jPanel2.add(Pharma_customer, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 400, 300, 90));

        Pharma_PlaceOrder.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Pharma_PlaceOrder.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Pharma_PlaceOrderMouseClicked(evt);
            }
        });

        jLabel20.setBackground(new java.awt.Color(240, 240, 240));
        jLabel20.setFont(new java.awt.Font("Yu Gothic UI", 0, 18)); // NOI18N
        jLabel20.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pharmacymanagementsystem/myicons/7581523_order_confirmation_application_check_smartphone_icon.png"))); // NOI18N
        jLabel20.setText("PLACE ORDER");

        javax.swing.GroupLayout Pharma_PlaceOrderLayout = new javax.swing.GroupLayout(Pharma_PlaceOrder);
        Pharma_PlaceOrder.setLayout(Pharma_PlaceOrderLayout);
        Pharma_PlaceOrderLayout.setHorizontalGroup(
            Pharma_PlaceOrderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Pharma_PlaceOrderLayout.createSequentialGroup()
                .addGap(76, 76, 76)
                .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(65, Short.MAX_VALUE))
        );
        Pharma_PlaceOrderLayout.setVerticalGroup(
            Pharma_PlaceOrderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Pharma_PlaceOrderLayout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(29, Short.MAX_VALUE))
        );

        jPanel2.add(Pharma_PlaceOrder, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 510, 300, 90));

        jLabel26.setBackground(new java.awt.Color(38, 143, 249));
        jLabel26.setFont(new java.awt.Font("Yu Gothic UI", 0, 18)); // NOI18N
        jLabel26.setForeground(new java.awt.Color(255, 255, 255));
        jLabel26.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pharmacymanagementsystem/myicons/icons8-manufacture-30.png"))); // NOI18N
        jLabel26.setText("LOGOUT");
        jLabel26.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel26.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel26MouseClicked(evt);
            }
        });
        jPanel2.add(jLabel26, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 910, -1, 33));

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 1020));

        jTextField1.setBackground(new java.awt.Color(0, 0, 255));
        jTextField1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jTextField1.setForeground(new java.awt.Color(255, 255, 255));
        jTextField1.setText("CART");
        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });
        getContentPane().add(jTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(940, 710, -1, -1));

        jLabel13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pharmacymanagementsystem/myicons/2457279.jpg"))); // NOI18N
        jLabel13.setText("jLabel13");
        getContentPane().add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 80, 1700, 950));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jLabel21MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel21MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel21MouseClicked

    private void Pharma_InventoryMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pharma_InventoryMouseClicked

   	Pharmacist_InventoryPMS PhInventory=new Pharmacist_InventoryPMS();
        this.setVisible(false);
        PhInventory.setVisible(true);


    }//GEN-LAST:event_Pharma_InventoryMouseClicked

    private void jLabel10MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel10MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel10MouseClicked

    private void Pharma_DashboardMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pharma_DashboardMouseClicked
	Pharmacist_DashboardPMS PhDashboard=new Pharmacist_DashboardPMS();
        this.setVisible(false);
        PhDashboard.setVisible(true);

    }//GEN-LAST:event_Pharma_DashboardMouseClicked

    private void Pharma_customerMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pharma_customerMouseClicked

       Pharmacist_customerPMS Phcustomer=new Pharmacist_customerPMS();
       this.setVisible(false);
       Phcustomer.setVisible(true);

    }//GEN-LAST:event_Pharma_customerMouseClicked

    private void txtQ2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtQ2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtQ2ActionPerformed

    private void txtQ3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtQ3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtQ3ActionPerformed

    private void patientidActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_patientidActionPerformed
        //Cid=Integer.parseInt(txtcid.getText());
    }//GEN-LAST:event_patientidActionPerformed

    private void contactActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_contactActionPerformed
        //cContact= txtcontact1.getText();
    }//GEN-LAST:event_contactActionPerformed

    private void customernameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_customernameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_customernameActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed

        addToCart();
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    private void InvoicebtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_InvoicebtnActionPerformed
         InvoicePMS inv = new InvoicePMS();
        this.setVisible(false);
        inv.setVisible(true);
        String customerName = customername.getText().trim();
        String contactNo = contact.getText().trim();
        String customerEmail = email.getText().trim();
        String date = getCurrentDate();

        // Calculate total items and total amount
        int totalItems = 0;
        double totalAmount = 0.0;
        for (int i = 0; i < cartModel.getRowCount(); i++) {
            int quantity = Integer.parseInt(cartModel.getValueAt(i, 4).toString());
            double unitPrice = Double.parseDouble(cartModel.getValueAt(i, 3).toString());
            totalItems += quantity;
            totalAmount += quantity * unitPrice;
        }

        try (Connection connection = GETCONNECTION()) {
            if (connection != null) {
                // Call the InsertBillCustomerStaff procedure
                try (CallableStatement statement = connection.prepareCall("{CALL InsertBillCustomerStaff(?, ?, ?, ?, ?, ?,)}")) {
                    statement.setString(1, customerName);
                    statement.setString(2, contactNo);
                    statement.setString(3, customerEmail);
                    statement.setInt(4, totalItems);
                    statement.setDouble(5, totalAmount);
                    statement.setString(6, date);
                    statement.execute();
                }

                JOptionPane.showMessageDialog(this, "Bill added");
            } else {
                JOptionPane.showMessageDialog(this, "Failed to connect to the database.");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "SQL Exception: " + e.getMessage());
        }
    }

    private String getCurrentDate() {
        LocalDate currentDate = LocalDate.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        return currentDate.format(formatter);
    }//GEN-LAST:event_InvoicebtnActionPerformed

    private void emailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_emailActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_emailActionPerformed

    private void Pharma_PlaceOrderMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pharma_PlaceOrderMouseClicked
  
	Pharmacist_OrderPMS PhOrder = new Pharmacist_OrderPMS();
        this.setVisible(false);
        PhOrder.setVisible(true);
    }//GEN-LAST:event_Pharma_PlaceOrderMouseClicked

    private void jLabel22MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel22MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel22MouseClicked

    private void jLabel26MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel26MouseClicked
        HomePagePM hpg=new HomePagePM();
        this.setVisible(false);
        hpg.setVisible(true);

        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel26MouseClicked

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Pharmacist_OrderPMS.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Pharmacist_OrderPMS.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Pharmacist_OrderPMS.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Pharmacist_OrderPMS.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Pharmacist_OrderPMS().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable CartTable;
    private javax.swing.JButton Invoicebtn;
    private javax.swing.JPanel Pharma_Dashboard;
    private javax.swing.JPanel Pharma_Inventory;
    private javax.swing.JPanel Pharma_PlaceOrder;
    private javax.swing.JPanel Pharma_customer;
    private javax.swing.JTextField contact;
    private javax.swing.JTextField customername;
    private javax.swing.JTextField email;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel83;
    private javax.swing.JLabel jLabel84;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLabel jLabel90;
    private javax.swing.JLabel jLabel91;
    private javax.swing.JLabel jLabel92;
    private javax.swing.JLabel jLabel93;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField patientid;
    private javax.swing.JTextField txtQ2;
    private javax.swing.JTextField txtQ3;
    private javax.swing.JTable viewinventorytable;
    // End of variables declaration//GEN-END:variables
}
