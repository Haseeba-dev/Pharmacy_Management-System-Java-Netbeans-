package pharmacymanagementsystem;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JOptionPane;

public class CONNECTION {

    public static Connection con = null;

    public static Connection GETCONNECTION() {
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            con = DriverManager.getConnection("jdbc:sqlserver://localhost\\SQLEXPRESS01:1433;databaseName=pharmacymanagementsystem;encrypt=true;trustServerCertificate=true","admin","1234");
            System.out.println("Connected");
           // JOptionPane.showMessageDialog(null, "Succesfull database Connection");
        } catch (ClassNotFoundException | SQLException ex) {
            System.out.println("ERROR MESSAGE: " + ex.getMessage());
        }
        return con;
    }
public static boolean authenticateUserA(String enteredAdminID, String enteredPassword) {
    try (Connection connection = GETCONNECTION()) {
        if (connection != null) {
            // SQL query to check if the AdminID exists in the ADMIN table
            String query = "SELECT * FROM ADMIN WHERE AdminID = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setString(1, enteredAdminID);

                // Execute the query
                ResultSet resultSet = preparedStatement.executeQuery();

                // Check if any rows are returned
                if (resultSet.next()) {
                    // Directly check if the entered password is '1234'
                    if (enteredPassword.equals("1234")) {
                        return true; // Password matches, authentication successful
                    } else {
                        System.out.println("Invalid password.");
                    }
                } else {
                    System.out.println("AdminID not found.");
                }
            }
        } else {
            System.out.println("Failed to connect to the database.");
        }
    } catch (SQLException e) {
        System.out.println("SQL Exception: " + e.getMessage());
    }
    return false;
}
public static boolean authenticateUserP(String enteredStaffID, String enteredPassword) {
    try (Connection connection = GETCONNECTION()) {
        if (connection != null) {
            // SQL query to check if the AdminID exists in the ADMIN table
            String query = "SELECT * FROM STAFF WHERE StaffID = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setString(1, enteredStaffID);

                // Execute the query
                ResultSet resultSet = preparedStatement.executeQuery();

                // Check if any rows are returned
                if (resultSet.next()) {
                    // Directly check if the entered password is '1234'
                    if (enteredPassword.equals("1234")) {
                        return true; // Password matches, authentication successful
                    } else {
                        System.out.println("Invalid password.");
                    }
                } else {
                    System.out.println("StaffID not found.");
                }
            }
        } else {
            System.out.println("Failed to connect to the database.");
        }
    } catch (SQLException e) {
        System.out.println("SQL Exception: " + e.getMessage());
    }
    return false;
}
//    public static void closeConnection() {
//        try {
//            if (con != null && !con.isClosed()) {
//                con.close();
//                System.out.println("Connection closed");
//            }
//        } catch (SQLException ex) {
//            System.out.println("Error while closing connection: " + ex.getMessage());
//        }
//    }

    public static void main(String[] args) {
//       Connection connection = GETCONNECTION();
        HomePagePM tp=new HomePagePM();
        tp.setVisible(true);
        // Perform operations with the connection...

//        closeConnection(); // Close the connection when done.
    }
}